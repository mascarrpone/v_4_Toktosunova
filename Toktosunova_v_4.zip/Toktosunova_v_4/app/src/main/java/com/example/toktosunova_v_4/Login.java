package com.example.toktosunova_v_4;


import static com.example.toktosunova_v_4.DBHelper.COLUMN_PASSWORD;
import static com.example.toktosunova_v_4.DBHelper.COLUMN_USERNAME;
import static com.example.toktosunova_v_4.DBHelper.TABLE_USERS;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    private DBHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        TextView login = findViewById(R.id.login);
        TextView password = findViewById(R.id.passw);
        Button signInButton = findViewById(R.id.btnSign);

        dbHelper = new DBHelper(this);
        db = dbHelper.getWritableDatabase();

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredUsername = login.getText().toString();
                String enteredPassword = password.getText().toString();

                Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                                " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                        new String[]{enteredUsername, enteredPassword});

                if (cursor.getCount() > 0) {
                    // Введенные данные совпадают с данными в базе
                    Toast.makeText(Login.this, "Успешный вход!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this, Personal_area.class);
                    startActivity(intent);
                } else {
                    // Введенные данные не совпадают с данными в базе
                    Toast.makeText(Login.this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
                }
                cursor.close();
            }
        });

    }
}