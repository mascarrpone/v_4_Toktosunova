package com.example.toktosunova_v_4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class Personal_area extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_area);

        Button btnOpenMap = findViewById(R.id.btnOpenMap);
        ImageButton backToLogin = findViewById(R.id.backToLogin);
        ImageButton btnStatistic = findViewById(R.id.btnStatistic);

        backToLogin.setOnClickListener(this);
        btnStatistic.setOnClickListener(this);
        btnOpenMap.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent intent;

        if (v.getId() == R.id.btnOpenMap) {
            intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:55.043816, 82.917108"));
            startActivity(intent);
        } else if (v.getId() == R.id.backToLogin) {
            startActivity(new Intent(Personal_area.this, Login.class));
    } else if (v.getId() == R.id.btnStatistic) {
            startActivity(new Intent(Personal_area.this, Statistic.class));
        }
    }}